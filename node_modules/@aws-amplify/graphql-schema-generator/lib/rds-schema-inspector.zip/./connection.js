"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.establishDBConnection = void 0;
const fs = require("fs");
const path = require("path");
const knex_1 = require("knex");
const establishDBConnection = (config) => {
    const databaseConfig = {
        host: config.host,
        database: config.database,
        port: config.port,
        user: config.username,
        password: config.password,
        ssl: {
            rejectUnauthorized: true,
            ca: getRDSCertificate(),
        },
    };
    try {
        return (0, knex_1.default)({
            client: config.engine === 'postgres' ? 'pg' : 'mysql2',
            connection: databaseConfig,
            pool: {
                min: 5,
                max: 30,
                createTimeoutMillis: 30000,
                acquireTimeoutMillis: 30000,
                idleTimeoutMillis: 30000,
                reapIntervalMillis: 1000,
                createRetryIntervalMillis: 100,
            },
            debug: false,
        });
    }
    catch (err) {
        console.log(err);
        throw err;
    }
};
exports.establishDBConnection = establishDBConnection;
const getRDSCertificate = () => {
    // This certificate file is copied from the parent folder `amplify-graphql-schema-generator/certs/aws-rds-global-bundle.pem`.
    const RDS_CERT_FILE_NAME = 'aws-rds-global-bundle.pem';
    const certPath = path.join(__dirname, 'certs', RDS_CERT_FILE_NAME);
    return fs.readFileSync(certPath, 'utf-8');
};
//# sourceMappingURL=connection.js.map